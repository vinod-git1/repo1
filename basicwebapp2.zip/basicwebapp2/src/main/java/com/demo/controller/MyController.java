package com.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.demo.main.myApp;
import com.demo.model.UserInfo;

@Controller
public class MyController {
	@ModelAttribute
	public void addAccountToModel(Model model) {
		System.out.println("Making sure account object is on model");
			if(!model.containsAttribute("aNewAccount")){
				UserInfo a = new UserInfo();
				model.addAttribute("userinfo", a);
			}
	}	
	@RequestMapping(value="/Welcome")
	public String getWelcome(@ModelAttribute ("userinfo") UserInfo userinfo) 
	{
		System.out.println(userinfo.getUsername());
		System.out.println(userinfo.getPassword());
		return "Welcome";
	}
	
	@RequestMapping(value="/validate")
	public String validateinfo(@ModelAttribute ("userinfo") UserInfo userinfo,Model model)
	{
		System.out.println("inside validation");
		System.out.println(userinfo.getUsername());
		System.out.println(userinfo.getPassword());
		String uname=userinfo.getUsername();
		String pwd=userinfo.getPassword();
		
		
//		System.out.println(uname);
//		System.out.println(pwd);
		
		
		model.addAttribute("uname", uname);
		String finalpage="";
		

//		System.out.println("Calling main fromController");
		
		String res=myApp.main(new String[] {uname,pwd});
		
//		System.out.println("received result from main");
		
		switch(res)
		{
		case "validuser":finalpage="/validuser";break;
		case "invaliduser":finalpage="/invaliduser";break;
		case "invalidpassword":finalpage="/invalidpassword";break;
		default:finalpage="/invaliduser";
		
		}
		
//		if (res.equals("validuser")) {
//			finalpage="/validuser";
//		}
//		else if (res.equals("invalidpassword")) {
//			finalpage= "/invalidpassword";
//		}
//		else if(res.equals("invaliduser")){
//			finalpage= "/invaliduser";
//		}
//		else {
//			finalpage= "/invaliduser";
//		}
//		
////		if (res.equals("invaliduser")) {
////			finalpage= "/invaliduser";
////			
////		}
//		
		
		return finalpage;
		
		
		
	}

}
