package com.demo.model;

import org.springframework.stereotype.Component;
import javax.validation.constraints.*;

@Component("userinfo")
public class UserInfo {
	public UserInfo() {
		super();
	}
	
	@Size(min=3,max=10)
	private String Username;
	
	@Size(min=6,max=13)
	private String Password;
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public UserInfo(String username, String password) {
		super();
		Username = username;
		Password = password;
	}

}
